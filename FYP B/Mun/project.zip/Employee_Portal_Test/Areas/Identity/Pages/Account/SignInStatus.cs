﻿namespace Employee_Portal_Test.Areas.Identity.Pages.Account
{
    public class SignInStatus
    {
    }
}