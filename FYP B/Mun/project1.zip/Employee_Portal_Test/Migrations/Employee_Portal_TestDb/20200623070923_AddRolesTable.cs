﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Employee_Portal_Test.Migrations.Employee_Portal_TestDb
{
    public partial class AddRolesTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
